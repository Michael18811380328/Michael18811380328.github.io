You can change the Max_Choice_Num to set the most leaves that red player can choose.









