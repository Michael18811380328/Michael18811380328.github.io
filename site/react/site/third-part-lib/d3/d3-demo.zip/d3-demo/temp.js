var svg = d3.select("svg");
svg.on("click", function () {
    var mouse = d3.mouse(this);

    var pointer = svg
        .append("use")
        .datum({x: mouse[0], y: mouse[1], selected: false})
        .attr("id", "currentPointer")
        .attr("href", "#pointer")
        .attr("transform", "translate(" + mouse[0] + "," + mouse[1] + ")scale(0)")
        .attr("fill", "#039BE5")
        .attr("stroke", "#039BE5")
        .attr("stroke-width", "1px");

    pointer
        .transition()
        .duration(500)
        .attr("transform", "translate(" + mouse[0] + "," + mouse[1] + ") scale(1)")
        .attr("x", mouse[0])
        .attr("y", mouse[1])
        .attr("transform", "scale(1)");

    pointer.on("click", function () {
        if (d3.event.ctrlKey) {
            pointer.transition()
                .duration(500)
                .attr("transform", "translate(" + pointer.attr("x") + "," + pointer.attr("y") + ") scale(0)")
                .remove();
        } else {
            var datum = pointer.datum();
            if (pointer.datum().selected) {
                datum.selected = false;
                pointer
                    .datum(datum)
                    .transition()
                    .duration(500)
                    .attr("stroke", "#039BE5")
                    .attr("stroke-width", "1px");
            } else {
                datum.selected = true;
                pointer
                    .datum(datum)
                    .transition()
                    .duration(500)
                    .attr("stroke", "#455A64")
                    .attr("stroke-width", "3px");
            }
        }
        d3.event.stopPropagation();
    });

    var dragHandler = d3.drag()
        .on("drag", function (d) {
            d3.select(this)
                .attr("x", d.x = d3.event.x)
                .attr("y", d.y = d3.event.y);
        });

    dragHandler(pointer);
});