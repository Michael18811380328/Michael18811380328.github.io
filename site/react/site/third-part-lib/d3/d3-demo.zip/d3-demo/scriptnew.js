//newcode
let FLAGPlayer = 0
let cc = 0
//newcode
var tooltip = d3.select("#body")
    .append("div")
    .attr("class", "tooltip")
    .style("z-index", "10")//10
    .style("opacity", 0)


function getColor(d) {
    // if (d.data.dummy_color) return d.data.dummy_color
    
    // if (d.data.color) return d.data.color
    if (d.data.chosen) return colorMap.red_process2
    if (d.data.red_end) {
        return  colorMap.red_end  
    } else if(d.data.firstStage){
        return colorMap.red_process
    } else if (d.data.blue) {
        return  colorMap.end
    } else {
        return colorMap.normal
    }
}
class Tree{
    constructor(lc, rc){
        this.lc = lc.bind(this)
        this.rc = rc.bind(this)
    }
    run(tree){
        const width = window.innerWidth;
		const height = window.innerHeight / 2;
        const radius = 40;
		const gcon = 0;
		
		
        const arc = d3.arc()
                .startAngle(d => d.x0)
                .endAngle(d => d.x1)
                .padAngle(d => Math.min((d.x1 - d.x0) / 2, 0.005))//0.005
                .innerRadius(d => d.y0  * radius )   //+ Math.pow(1.5,d.depth-1)
                .outerRadius(d => Math.max(d.y0 * radius, d.y1 * radius - 1))// + Math.pow(1,d.depth-1)) //newcode
                .padRadius(radius* 1.5 )
    
        const partition = data => {
            const root = d3.hierarchy(data)
                    .sum(d => d.size)
                    .sort((a, b) => b.value - a.value);
            return d3.partition()
                    .size([2 * Math.PI, root.height + 1])
                    (root);
        };
        var data = tree
        const root = partition(data);
        
        root.each(d => d.current = d);
        
        d3.select('#partitionSVG').selectAll('*').remove()

        const svg = d3.select('#partitionSVG')
                .style("width", "100%")
                .style("height", "100%")
                .style("font", "10px monospace") // key2   about the size of the label
				
        const g = svg.append("g")
                .attr("transform", `translate(${width / 2},${height})`);

        g.append("g")
                .selectAll("path")
                .data(root.descendants().slice(1))
                .join("path")
                .attr("fill", getColor)
                .attr("d", d => arc(d.current))
                .on('click', d =>{  //目前来说应该是只有红方用到click， 蓝方应该用drag事件。
                    if(FLAGPlayer == 0){  //表示是红方的轮次
                        if (d.data.isLeaf) {
                            this.lc(d)
                        }
                        d3.event.preventDefault()
                    }
                    // else if(FLAGPlayer == 1 && cc == 0){ //表示蓝方的轮次，然后点击了红方
                    //     if (d.data.isLeaf) {
                    //         this.rc(d)
                    //         // cc = 1
                    //     }
                    //     d3.event.preventDefault()
                    // }else if(FLAGPlayer == 1 && cc == 1){  //表示蓝方的轮次，然后点击了普通方
                    //     if (d.data.isLeaf) {
                    //         this.rc(d)
                    //         // cc = 0
                    //     }
                    //     d3.event.preventDefault()
                    // }
                })
                .on("mouseover", function(d) {
                    d3.selectAll("path")
                        .style("opacity", 1);
                    
                    //获得这条路径。
                    var sequenceArray = d.ancestors().reverse();
                    sequenceArray.shift(); 
                    
                    const arrowEle = document.getElementsByClassName('arrow')[0]
                    arrowEle.innerHTML = sequenceArray//sdf
                        //.map(i => `<div class="arrow-item" style="background-color:${getColor(i)};font-size:x-small;border-color:${getColor(i)};">${i.data.label.split('/')[0]}</div>`)
                       // key1 show Double_labels in path.    we need not to split the i.data.label
                        .map(i => `<div class="arrow-item" style="background-color:${getColor(i)};font-size:x-small;border-color:${getColor(i)};">${i.data.label}</div>`)
                        .join('')
                    svg.selectAll("path")
                    .filter(function(node) {
                                return (sequenceArray.indexOf(node) >= 0);
                            })
                    .style("opacity", 0.8);

                    tooltip.html(d.data.label)
                    // return tooltip.transition()
                    //   .duration(50)
                    //   .style("opacity", 0.9)
                  })
                .on("mousemove", function(d) {
                    return tooltip
                      .style("top", (d3.event.pageY+0)+"px")//+10
                      .style("left", (d3.event.pageX+0)+"px");//+10
                  })

                .call(
                    d3.drag()
                        .on('start', () => {
                            const { x, y } = d3.event
                            console.log('开始拖拽', x, y);
                            window.dx = 0;
                            window.dy = 0;
                        })
                        .on('end', () => {
                            const { x, y } = d3.event
                            console.log('拖拽结束', x, y);
                            // 清空当前的位置
                            d3.select(this)
                            .attr("transform", `translate(${0},${0})`);
                            window.dx = 0;
                            window.dy = 0;
                            console.log(this);
                        })
                        .on('drag', draged)
                )


                .on("mouseout", function(d){
                    var demoP=document.getElementById("sequencetxt");
                    demoP.innerHTML = "";
                    d3.selectAll("path")
                        .style("opacity", 1);
                    return tooltip.style("opacity", 1);
                  })
                  

                  d3.selectAll('g').call(d3.drag().
                        on("start", d =>{
                            // if (d.data.isLeaf) {
                            //     if(FLAGPlayer == 1 && cc == 0){ //表示蓝方的轮次，然后点击了红方
                            //         if (d.data.isLeaf) {
                            //             this.rc(d)
                            //         }
                            //         // d3.event.preventDefault()
                            //     }
                            // }
                        }
                           )
                        .on("end",d =>{
                            if (d.data.isLeaf) {
                                // if(FLAGPlayer == 1 && cc == 1){  //表示蓝方的轮次，然后点击了普通方
                                //     if (d.data.isLeaf) {
                                //         // alert('End node')
                                //         this.rc(d)
                                //     }
                                //     // d3.event.preventDefault()
                                // }
                            }}
                        )
                  )
       
        g.append("g")
                .attr("pointer-events", "none")
                .attr("text-anchor", "middle")
                .style("user-select", "none")
                .selectAll("text")
                .data(root.descendants().slice(1))
                .join("text")
                .attr("dy", "0.35em")
                .attr("transform", d => labelTransform(d.current))
                //key2 if you do not want to show the label on the disk, just comment out the following sentence
                .text(d => d.data.label);
                // 如果拖动数字，那么需要在这里增加拖拽事件


        function labelTransform(d) {
            const x = (d.x0 + d.x1) / 2 * 180 / Math.PI;
            const y = (d.y0 + d.y1) / 2 * radius;
            return `rotate(${x - 90}) translate(${y},0) rotate(${x < 180 ? 0 : 180})`;
        }

        function draged(e) {
            // console.log('label is ', e.data.label);
            // cx, cy
            const { x, y, dx, dy, subject } = d3.event
            // console.log(subject); 这个是当前拖拽的对象
            // console.log('当前的坐标是： ', x, y);
            // 获取当前的元素，并设置拖拽的位置
            console.log(dx, dy);
            
            window.dx += dx;
            window.dy += dy;

            // this.cx = x;
            // this.cy = y;

            // console.log();
            // 这个获取当前的位置，然后获取差值，就是需要的 translate x y 值

            d3.select(this)
                .attr('cx', x)
                .attr('cy', y)
                .attr("transform", `translate(${window.dx},${window.dy})`);
        
            console.log(this);
        }
    }
}