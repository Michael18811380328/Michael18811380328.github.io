const colorMap = {
    normal: '#6699FF',
    red_process: '#e14089',  //这个颜色是红方刚刚选中后的颜色
    red_process2:'#8c0442',  //这个颜色是蓝方刚刚选中红方节点后的颜色，深色
    end: '#9966FF',//#b03ce9 //表示蓝方结束了
    dark_end:'#663399',
    red_end: 'lightgreen',
}
let status = 'process'
let next = 'red'

const tree = {
    label: '0',
    children: [],
    color: colorMap.未选择,
    isLeaf: false,
    // dummy: new Set(),
}
const depth = 6
const cache = {
    0: [tree]
}
const Max_Choice_Num = 3  // this is a constraint for Red player
let cur_red_choice_num = 0  //表示当前红色玩家一共选中了多少个节点。
// let DUMMY = false  //new code
let redNowLabel =  ''
let blueClickCount = 1
let count = 1
let isDoubleLabel = label => {
    return /\d+\/\d+/g.test(label)
}
function error(msg){
    alert(msg || 'Blue Error！！')
}
for (let i = 0; i < depth - 1; i++) {
    cache[i + 1] = []
    for(let c of cache[i]) {
        let c1 = {
            label: count++ + '',
            children: [],
            isLeaf: i === depth - 2,
            p: c,
            // dummy: new Set(),
        }
        let c2 = {
            label: count++ + '',
            children: [],
            isLeaf: i === depth - 2,
            p: c,
            // dummy: new Set(),
        }
        if (i === depth - 2) {
            c1.size = i
            c2.size = i
        }
        c.children = [c1, c2]
        cache[i+1].push(c1, c2)
    }
}
function checkNodeCanClick(d){ //check for blue player
    if (d.data.red_end) return false   
    if (d.data.blue) return false
    if (d.data.firstStage) return false
    if (d.data.chosen) return false  
    return true
}
const single = {  //single label of red player suitation (leaf node)
    check(bluelabel, redlabel) {   //check the strategy of blue player
        let blueNode = findNodeTo(tree, bluelabel)
        let redNode = findNodeTo(tree, redlabel)
        while (blueNode !== redNode) {
            let _r_label = redNode.label.split('/')[0]
            let _b_label = blueNode.label.split('/')
            if (_b_label.length === 2 && !_b_label.includes(_r_label)) {
                error()
                return
            }
            blueNode = blueNode.p
            redNode = redNode.p
        }
        return true
    },
    handle(bluelabel, redlabel) {   //change the corresponding color and label
        let blueNode = findNodeTo(tree, bluelabel)
        let redNode = findNodeTo(tree, redlabel)
        while (blueNode !== redNode) {
            if (!isDoubleLabel(blueNode.label)) {
                blueNode.label += '/' + redNode.label.split('/')[0]
            }
            // blueNode.dummy_color = false  //no matter the blueNode is dummy or not, it should become purple first
            blueNode.blue = true
            blueNode = blueNode.p
            redNode = redNode.p
        }
    }
}


function onlclick(d) {   //left click  for  red player
    
    if (FLAGPlayer == 1)  { //表示红方已经耗尽了他的选项
        return    
    }
    if (d.data.firstStage) return   //看看红方是不是又选择了之前选过的选项
        
    cur_red_choice_num += 1   //表示红方实际的选择个数
    
    findNodeTo (tree, d.data.label, node => {  //找到相应的红方节点，并重新画树
        node.firstStage = true
        node.red_end = false
        node.chosen = false
        node.blue = false
    })

    this.run(tree)

    if (cur_red_choice_num == Max_Choice_Num){
        FLAGPlayer = 1  //表示轮到蓝方了
    }
}

function Blue_Step_1(d){  //表示蓝方的第一步
 //（1）第一个判断，红方节点是否可以被拖拽，有的红方节点已经被成功化解了（变成了绿色），应该无法被拖动
    //这个判断不需要弹窗，直接把其拖动结束后，红方相应节点的draggable属性改为false即可。
    //其他非叶节点均不可被拖动。这个方法对应了两个事件，比如，开始点击红方的一个节点，redNowLabel = d.data.label。应该
    //能够获取到红方的label,
    if(FLAGPlayer == 1 && d.data.firstStage ){//首先这得是蓝方的轮次，然后是点击红色节点的轮次 
        
        redNowLabel = d.data.label
        // alert("Blue_Step_1" + redNowLabel)
        
        findNodeTo(tree, redNowLabel, node => {  //找到相应的红方节点，并重新画树
            node.chosen = true
            node.firstStage = false
            node.red_end = false
            node.blue = false
        })
        cc = 1 
    } 
}
// 然后拖到目的节点后，放下，应该获取到蓝方的label
function Blue_Step_2(d) {   // this is blue player's turn
    //（2）第二个判断，判断目的地节点是否是一个可以droppable的蓝色节点，比如不能是双节点的，也就可以了。
    // 因为在这个场景下，只有紫色的节点是双节点，这个是成功化解的局面。
    // alert("Blue_Step_2"+redNowLabel)
    if (isDoubleLabel(d.data.label)) return   //表示该叶节点已经是双标签了，不能够再作为蓝方的选项了。
    if (!checkNodeCanClick(d)) return   //表示不能够点击红方已经选择过的节点，和蓝方已经选择过的节点，和上边一行稍有重复
   
    
    if (!single.check(d.data.label, redNowLabel)) return    //判断这个化解方案是否正确
    
    // status = 'end'
    findNodeTo(tree, redNowLabel, node => {
        node.chosen = false
        node.firstStage = false
        node.red_end = true
        node.blue = false
    })
    findNodeTo(tree, d.data.label, node => {
        node.blue = true
        node.chosen = false
        node.firstStage = false
        node.red_end = false
    })
    single.handle(d.data.label, redNowLabel)
    cc = 0
}

function onrclick(d){  //蓝方的一个小回合
    if( cc == 0 ){
        Blue_Step_1(d)
    }
    if( cc == 1){
        Blue_Step_2(d) 
    }
    this.run(tree) 
}

function findNodeTo(node, label, handle = () => {}) {  //find the node with the appointed label
    if (node.label === label) {
        handle(node)
        return node
    } else if (node.children.length) {
        return findNodeTo(node.children[1], label, handle) || findNodeTo(node.children[0], label, handle)
    } else {
        return    //return undefined
    }
}

const treemap = new Tree(onlclick, onrclick)  
treemap.run(tree)